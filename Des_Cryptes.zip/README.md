# SAE SHELL

> Cette SAE vous est présentée par BRUN Dylan, CARON Sebastian, MAGIEU Pierre

## Description

Cette magnifique SAE à pour but de créer un script bash permettant la traduction de fichiers ou d'input en utilisant différents chiffrement comme Caesar, Vigenere et le Morse.

[Le lien vers le Rapport !](https://docs.google.com/document/d/1Lk8nq1e_kyfWSWNiCctRRj6pmrh1at1ewCphH-zld9c/edit?usp=sharing).